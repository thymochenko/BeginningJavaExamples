Exercise 7 is a trick question to see if you have been paying attention. :-)
The last version of #sketcher in the chapter already implements custome colors!