// Bank account transaction types
public enum TransactionType {DEBIT, CREDIT }

