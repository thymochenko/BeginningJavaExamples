import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class FindingNumbers {
  public static void main(String args[]) {
    String regEx = "[+|-]?(\\d+(\\.\\d*)?)|(\\.\\d+)";
    String str = "256 is the square of 16 and -2.5 squared is 6.25 " + "and -.243 is less than 0.1234.";
    Pattern pattern = Pattern.compile(regEx);
    Matcher m = pattern.matcher(str);
    String subStr = null;
    while(m.find()) {
      System.out.println(m.group());                                   // Output the substring matched
    }
  }
}
