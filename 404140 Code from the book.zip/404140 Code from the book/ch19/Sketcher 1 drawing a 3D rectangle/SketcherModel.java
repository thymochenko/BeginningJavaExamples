import java.io.Serializable;
import java.util.Observable;

public class SketcherModel extends Observable implements Serializable {
  // Detail of the rest of class to be filled in later...
  private final static long serialVersionUID = 1001L;
}
